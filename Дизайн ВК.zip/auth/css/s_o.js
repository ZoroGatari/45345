<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html>
<head>
  <title>404 Not Found</title>
</head>
<body style="background: #3f5d81 url(https://vk.com/images/error404.png) no-repeat 50% 50%; width: 100%; height: 100%; overflow: hidden; margin: 0px;">
<a style="position: absolute; left: 50%; top: 50%; margin: -265px -345px 0px; height: 530px; width: 690px;" href="https://vk.com/"></a>
</body>
</html>
